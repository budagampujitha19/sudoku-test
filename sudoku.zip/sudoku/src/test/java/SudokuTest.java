import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import java.util.function.Consumer;

import java.io.File;

public class SudokuTest {
    @Test
    void shouldValidateSudoku() {

        Sudoku sudoku = new Sudoku();

        File file = new File("src/test/java/dummydata.txt");

//        String result = sudoku.run();

        Assertions.assertEquals("VALID", "VALID");
    }
}

